package com.catandroid.app.common.components.hexGridUtils;

/**
 * Created by logan on 2017-01-31.
 */

public class HexPoint
{
    public HexPoint(double x, double y)
    {
        this.x = x;
        this.y = y;
    }
    public final double x;
    public final double y;
}
