package com.catandroid.app.common.components;

import com.catandroid.app.common.players.Player;

public class Edge {

	private int index;
	private int[] vertices;
	private Player owner;
	private int lastRoadCountId;
	private int originHex;
    private int originHexDirect;
    private int myHarbor = -1;
	private Board board;

	/**
	 * Initialize edge with vertices set to null
	 */
	public Edge(Board board, int index) {
		this.index = index;
		vertices = new int[2];
		vertices[0] = vertices[1] = -1;
		owner = null;
		lastRoadCountId = 0;
		this.board = board;
	}

	/**
	 * Set the board
	 *
	 * @param board
	 *
	 */
	public void setBoard(Board board) {
		this.board = board;
	}

	/**
	 * Set vertices for the edge
	 * 
	 * @param v1
	 *            the first vertices
	 * @param v2
	 *            the second vertices
	 */
	public void setVertices(int v1, int v2) {
		vertices[0] = v1;
		vertices[1] = v2;
		board.getVertex(v1).addEdge(index);
		board.getVertex(v2).addEdge(index);
	}

	/**
	 * Check if the edge has a given vertices
	 * 
	 * @param v
	 *            the vertices to check for
	 * @return true if v is associated with the edge
	 */
	public boolean hasVertex(int v) {
		return (vertices[0] == v || vertices[1] == v);
	}

	/**
	 * Get the other vertices associated with edge
	 * 
	 * @param v
	 *            one vertices
	 * @return the other associated vertices or null if not completed
	 */
	public int getAdjacent(int v) {
		if (vertices[0] == v) {
			return vertices[1];
		}
		else if (vertices[1] == v) {
			return vertices[0];
		}

		return -1;
	}

	/**
	 * Check if a road has been build at the edge
	 * 
	 * @return true if a road was built
	 */
	public boolean hasRoad() {
		return (owner != null);
	}

	/**
	 * Get the owner's player number
	 * 
	 * @return 0 or the owner's player number
	 */
	public Player getOwner() {
		return owner;
	}

	/**
	 * Determine if player can build a road on edge
	 * 
	 * @param player
	 *            the player to check for
	 * @return true if player can build a road on edge
	 */
	public boolean canBuild(Player player) {
		if (owner != null) {
			return false;
		}

		// check for roads to each vertices
		for (int i = 0; i < 2; i++) {
			// the player has a road to an unoccupied vertices,
			// or the player has an adjacent building
			if (board.getVertex(vertices[i]).hasRoad(player) && !board.getVertex(vertices[i]).hasBuilding()
					|| board.getVertex(vertices[i]).hasBuilding(player)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Set the origin hexagon
	 * @param h
	 *            the hex to set
	 * @return
	 */
	public void setOriginHex(int h) {
		this.originHex = h;
	}


	/**
	 * Get the origin hexagon
	 *
	 * @return the origin hexagon
	 */
	public int getOriginHex() {
		return originHex;
	}

    /**
     * Set the origin hexagon direction
     * @param direct
     *            the edge direction on origin hexagon
     * @return
     */
    public void setOriginHexDirect(int direct) {
        this.originHexDirect = direct;
    }

    /**
     * Get the origin hexagon direction
     * @return the origin hexagon direction
     */
    public int getOriginHexDirect() {
        return this.originHexDirect;
    }

    /**
     * Get the marginal X sign of the origin hexagon direction
     * @return the marginal X sign of the origin hexagon direction
     */
    public int getOriginHexDirectXsign() {
        switch(this.originHexDirect) {
            case 0:
                return 1;
            case 1:
                return 1;
            case 2:
                return 0;
            case 3:
                return -1;
            case 4:
                return -1;
            case 5:
                return 0;
            default:
                return Integer.MIN_VALUE;
        }
    }

    /**
     * Get the marginal X sign of the origin hexagon direction
     * @return the marginal X sign of the origin hexagon direction
     */
    public int getOriginHexDirectYsign() {
        switch(this.originHexDirect) {
            case 0:
                return 1;
            case 1:
                return -1;
            case 2:
                return -1;
            case 3:
                return -1;
            case 4:
                return 1;
            case 5:
                return 1;
            default:
                return Integer.MIN_VALUE;
        }
    }

    /**
     * Set a harbor on this edge
     * @param harbor
     *            the harbor to set
     * @return
     */
    public void setMyHarbor(int harbor) {
        board.getHarbor(harbor).setEdgeIndex(this.getIndex());
        this.myHarbor = harbor;
    }

    /**
     * Get the harbor on this edge
     * @return the harbor
     */
    public int getMyHarbor() {
        return this.myHarbor;
    }

	/**
	 * Get the first vertices
	 * 
	 * @return the first vertices
	 */
	public int getV0Clockwise() {
		return vertices[0];
	}

	/**
	 * Get the second vertices
	 * 
	 * @return the second vertices
	 */
	public int getV1Clockwise() {
		return vertices[1];
	}

	/**
	 * Get the index of this edge
	 * 
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * Build a road on edge
	 * 
	 * @param player
	 *            the road owner
	 * @return true if player can build a road on edge
	 */
	public boolean build(Player player) {
		if (!canBuild(player)) {
			return false;
		}

		owner = player;
		return true;
	}

	/**
	 * Get the road length through this edge
	 * 
	 * @param player
	 *            player to measure for
	 * @param from
	 *            where we are measuring from
	 * @param countId
	 *            unique id for this count iteration
	 * @return the road length
	 */
	public int getRoadLength(Player player, int from, int countId) {
		if (owner != player || lastRoadCountId == countId) {
			return 0;
		}

		// this ensures that that road isn't counted multiple times (cycles)
		lastRoadCountId = countId;

		// find other vertices
		int to = (from == vertices[0] ? vertices[1] : vertices[0]);

		// return road length
		return board.getVertex(to).getRoadLength(player, index, countId) + 1;
	}

	/**
	 * Get the longest road length through this edge
	 * 
	 * @param countId
	 *            unique id for this count iteration
	 * @return the road length
	 */
	public int getRoadLength(int countId) {
		if (owner == null) {
			return 0;
		}

		// this ensures that that road isn't counted multiple times (cycles)
		lastRoadCountId = countId;

		int length1 = board.getVertex(vertices[0]).getRoadLength(owner, index, countId);
		int length2 = board.getVertex(vertices[1]).getRoadLength(owner, index, countId);
		return length1 + length2 + 1;
	}
}
