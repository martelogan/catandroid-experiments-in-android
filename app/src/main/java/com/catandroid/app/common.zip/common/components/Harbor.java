package com.catandroid.app.common.components;

import com.catandroid.app.common.components.Resource.ResourceType;

public class Harbor {

	public enum Position {
		NORTH, SOUTH, NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST
	}

	// default positions
	private static final Position[] POSITIONS_BY_VDIRECT = {
			Position.NORTHEAST, Position.SOUTHEAST, Position.SOUTH,
			Position.SOUTHWEST, Position.NORTHWEST, Position.NORTH
	};

	private ResourceType resourceType;
	private Position position;
	private int id;
	private int edgeIndex;

	private transient Board board;

	public Harbor(ResourceType resourceType, int id, Board board) {
		this.resourceType = resourceType;
		this.id = id;
		this.board = board;
	}


	public void setBoard(Board board) {
		this.board = board;
	}

	public void setResourceType(ResourceType resourceType) {
		this.resourceType = resourceType;
	}

	public ResourceType getResourceType() {
		return resourceType;
	}

	public void setPosition(Position p) {
		this.position = p;
	}

	public Position getPosition() {
		return position;
	}

	public void setEdgeIndex(int edgeIndex) {
		this.edgeIndex = edgeIndex;
	}

	public Edge getEdgeIndex() {
		return board.getEdge(edgeIndex);
	}

	public static Position vdirectToPosition(int vdirect) {
		return POSITIONS_BY_VDIRECT[vdirect];
	}

	public int getIndex() {
		return id;
	}
}
